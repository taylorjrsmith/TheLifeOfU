The way i thought this could work. Instead of add a new node everytime.
someone submits a senario its gets stored on the right hand side in the grey container
There would show the title of the senario. And to view they can click it. 
Then there could be a submit all button at the bottom that i havent added yet 

NOTE: This is not the final build it has not been finished yet so please take it lightly :)
